import random




def toPaint():
    global A1A, A2A, A3A, A4A, A5A, A6A, A7A, A8A, A9A, A10A, A11A, A12A, A13A, A14A, A15A, A16A, A17A, A18A, A19A, A20A, A21A, A22A, A23A, A24A, A25A, A26A, A27A, A28A, A29A, A30A, A31A, A32A, A33A, A34A, A35A, A36A, A37A, A38A, A39A, A40A, A41A, A42A, A43A, A44A, A45A, A46A, A47A, A48A, A49A, A50A, B51B, B52B, B53B, B54B, B55B, B56B, B57B, B58B, B59B, B60B, B61B, B62B, B63B, B64B, B65B, B66B, B67B, B68B, B69B, B70B, B71B, B72B, B73B, B74B, B75B, B76B, B77B, B78B, B79B, B80B, B81B, B82B, B83B, B84B, B85B, B86B, B87B, B88B, B89B, B90B, B91B, B92B, B93B, B94B, B95B, B96B, B97B, B98B, B99B, B100B, C101C, C102C, C103C, C104C, C105C, C106C, C107C, C108C, C109C, C110C, C111C, C112C, C113C, C114C, C115C, C116C, C117C, C118C, C119C, C120C, C121C, C122C, C123C, C124C, C125C, C126C, C127C, C128C, C129C, C130C, C131C, C132C, C133C, C134C, C135C, C136C, C137C, C138C, C139C, C140C, C141C, C142C, C143C, C144C, C145C, C146C, C147C, C148C, C149C, C150C, D151D, D152D, D153D, D154D, D155D, D156D, D157D, D158D, D159D, D160D, D161D, D162D, D163D, D164D, D165D, D166D, D167D, D168D, D169D, D170D, D171D, D172D, D173D, D174D, D175D, D176D, D177D, D178D, D179D, D180D, D181D, D182D, D183D, D184D, D185D, D186D, D187D, D188D, D189D, D190D, D191D, D192D, D193D, D194D, D195D, D196D, D197D, D198D, D199D, D200D, E201E, E202E, E203E, E204E, E205E, E206E, E207E, E208E, E209E, E210E, E211E, E212E, E213E, E214E, E215E, E216E, E217E, E218E, E219E, E220E, E221E, E222E, E223E, E224E, E225E, E226E, E227E, E228E, E229E, E230E, E231E, E232E, E233E, E234E, E235E, E236E, E237E, E238E, E239E, E240E, E241E, E242E, E243E, E244E, E245E, E246E, E247E, E248E, E249E, E250E, F251F, F252F, F253F, F254F, F255F, F256F, F257F, F258F, F259F, F260F, F261F, F262F, F263F, F264F, F265F, F266F, F267F, F268F, F269F, F270F, F271F, F272F, F273F, F274F, F275F, F276F, F277F, F278F, F279F, F280F, F281F, F282F, F283F, F284F, F285F, F286F, F287F, F288F, F289F, F290F, F291F, F292F, F293F, F294F, F295F, F296F, F297F, F298F, F299F, F300F, G301G, G302G, G303G, G304G, G305G, G306G, G307G, G308G, G309G, G310G, G311G, G312G, G313G, G314G, G315G, G316G, G317G, G318G, G319G, G320G, G321G, G322G, G323G, G324G, G325G, G326G, G327G, G328G, G329G, G330G, G331G, G332G, G333G, G334G, G335G, G336G, G337G, G338G, G339G, G340G, G341G, G342G, G343G, G344G, G345G, G346G, G347G, G348G, G349G, G350G, H351H, H352H, H353H, H354H, H355H, H356H, H357H, H358H, H359H, H360H, H361H, H362H, H363H, H364H, H365H, H366H, H367H, H368H, H369H, H370H, H371H, H372H, H373H, H374H, H375H, H376H, H377H, H378H, H379H, H380H, H381H, H382H, H383H, H384H, H385H, H386H, H387H, H388H, H389H, H390H, H391H, H392H, H393H, H394H, H395H, H396H, H397H, H398H, H399H, H400H, I401I, I402I, I403I, I404I, I405I, I406I, I407I, I408I, I409I, I410I, I411I, I412I, I413I, I414I, I415I, I416I, I417I, I418I, I419I, I420I, I421I, I422I, I423I, I424I, I425I, I426I, I427I, I428I, I429I, I430I, I431I, I432I, I433I, I434I, I435I, I436I, I437I, I438I, I439I, I440I, I441I, I442I, I443I, I444I, I445I, I446I, I447I, I448I, I449I, I450I, J451J, J452J, J453J, J454J, J455J, J456J, J457J, J458J, J459J, J460J, J461J, J462J, J463J, J464J, J465J, J466J, J467J, J468J, J469J, J470J, J471J, J472J, J473J, J474J, J475J, J476J, J477J, J478J, J479J, J480J, J481J, J482J, J483J, J484J, J485J, J486J, J487J, J488J, J489J, J490J, J491J, J492J, J493J, J494J, J495J, J496J, J497J, J498J, J499J, J500J, K501K, K502K, K503K, K504K, K505K, K506K, K507K, K508K, K509K, K510K, K511K, K512K, K513K, K514K, K515K, K516K, K517K, K518K, K519K, K520K, K521K, K522K, K523K, K524K, K525K, K526K, K527K, K528K, K529K, K530K, K531K, K532K, K533K, K534K, K535K, K536K, K537K, K538K, K539K, K540K, K541K, K542K, K543K, K544K, K545K, K546K, K547K, K548K, K549K, K550K, L551L, L552L, L553L, L554L, L555L, L556L, L557L, L558L, L559L, L560L, L561L, L562L, L563L, L564L, L565L, L566L, L567L, L568L, L569L, L570L, L571L, L572L, L573L, L574L, L575L, L576L, L577L, L578L, L579L, L580L, L581L, L582L, L583L, L584L, L585L, L586L, L587L, L588L, L589L, L590L, L591L, L592L, L593L, L594L, L595L, L596L, L597L, L598L, L599L, L600L, M601M, M602M, M603M, M604M, M605M, M606M, M607M, M608M, M609M, M610M, M611M, M612M, M613M, M614M, M615M, M616M, M617M, M618M, M619M, M620M, M621M, M622M, M623M, M624M, M625M
    value1 = int(random.randint(0, 25) + 1)
    value2 = int(random.randint(0, 25) + 25)
    value3 = int(random.randint(0, 25) + 50)
    value4 = int(random.randint(0, 25) + 75)
    value5 = int(random.randint(0, 25) + 100)
    value6 = int(random.randint(0, 25) + 125)
    value7 = int(random.randint(0, 25) + 150)
    value8 = int(random.randint(0, 25) + 175)
    value9 = int(random.randint(0, 25) + 200)
    value10 = int(random.randint(0, 25) + 225)
    value11 = int(random.randint(0, 25) + 250)
    value12 = int(random.randint(0, 25) + 275)
    value13 = int(random.randint(0, 25) + 300)
    value14 = int(value12) + 50
    value15 = int(value11) + 100
    value16 = int(value10) + 150
    value17 = int(value9) + 200
    value18 = int(value8) + 250
    value19 = int(value7) + 300
    value20 = int(value6) + 350
    value21 = int(value5) + 400
    value22 = int(value4) + 450
    value23 = int(value3) + 500
    value24 = int(value2) + 550
    value25 = int(value1) + 600 - 1
    l = ('0', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 
     'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', 'B',
     'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C', 'C',
     'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D',
     'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E', 'E',
     'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F',
     'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G', 'G',
     'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H', 'H',
     'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I', 'I',
     'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J', 'J',
     'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K', 'K',
     'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L',
     'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M', 'M');
    a1 = l[value1] + str(value1) + l[value1]
    b1 = globals().get(a1)
    if b1:
        b1() 
    a1 = l[value2] + str(value2) + l[value2]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value3] + str(value3) + l[value3]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value4] + str(value4) + l[value4]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value5] + str(value5) + l[value5]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value6] + str(value6) + l[value6]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value7] + str(value7) + l[value7]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value8] + str(value8) + l[value8]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value9] + str(value9) + l[value9]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value10] + str(value10) + l[value10]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value11] + str(value11) + l[value11]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value12] + str(value12) + l[value12]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value13] + str(value13) + l[value13]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value14] + str(value14) + l[value14]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value15] + str(value15) + l[value15]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value16] + str(value16) + l[value16]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value17] + str(value17) + l[value17]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value18] + str(value18) + l[value18]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value19] + str(value19) + l[value19]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value20] + str(value20) + l[value20]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value21] + str(value21) + l[value21]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value22] + str(value22) + l[value22]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value23] + str(value23) + l[value23]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value24] + str(value24) + l[value24]
    b1 = globals().get(a1)
    if b1:
        b1()
    a1 = l[value25] + str(value25) + l[value25]
    b1 = globals().get(a1)
    if b1:
        b1()
    b1
        
    return




bButton = Button(zGreatSCS, text='Color', width='4', height='2', command=toPaint)

bButton.grid(row='3', column='3', sticky='NW')
